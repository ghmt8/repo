# Create a Windows 10 VM in VMware Workstation with Packer

For more information visit:
https://www.ivobeerens.nl/2022/05/31/build-a-windows-10-image-with-packer-using-vmware-workstation/