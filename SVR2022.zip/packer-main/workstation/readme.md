Packer VMware Workstation Windows 10
