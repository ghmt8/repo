Create a Windows 11 VM in Hyper-V Manager

