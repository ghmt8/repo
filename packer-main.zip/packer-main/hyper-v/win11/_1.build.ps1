<#
  Description: Download the latest version of Hashicorp Packer version and create a Windows Server 2022 VM in Hyper-V
#>

# Enable TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
# Speed up the invoke-webrequest command
$global:ProgressPreference = 'SilentlyContinue'

# Variables
$global:downloadfolder = "C:\temp\" # Packer location installed
$global:win11_downloadfolder = "C:\Temp\packer-main\hyper-v\win11\"
$global:packer_config = "windows.json.pkr.hcl" #Packer config file
$global:packer_variable = "windows.auto.pkrvars.hcl" # Packer variable file
#$env:winrm_admin = "admin"
#$env:winrm_password = "password"
$global:github = "https://github.com/ghmt8/repo/raw/main/packer-main.zip"
$global:product = "packer"
$global:packer_uri = "https://developer.hashicorp.com/packer/install"

# Check if the temp folder exist
If(!(test-path -PathType container $global:downloadfolder))
    {
      New-Item -ItemType Directory -Path $global:downloadfolder
}

# Go to the Packer download folder
Set-Location $global:downloadfolder

# Download Github files
Invoke-WebRequest -Uri $github -OutFile ${global:downloadfolder}packer-main.zip
Expand-Archive ${global:downloadfolder}packer-main.zip -DestinationPath $global:downloadfolder -Force

# Remove zip file
Remove-Item -Path ${downloadfolder}packer-main.zip 

# Download the latest version of Packer
$global:packurl = Invoke-WebRequest -Uri $global:packer_uri| Select-Object -Expand links | Where-Object href -match "//releases\.hashicorp\.com/$product/\d.*/$product_.*_windows_amd64\.zip$" | Select-Object -Expand href
$global:packdown = $global:packurl | Split-Path -Leaf
$global:packdownload = $global:downloadfolder + $global:packdown
Invoke-WebRequest $global:packurl -outfile $global:packdownload

# Unzip Packer 
Expand-Archive $global:packdownload -DestinationPath $global:win11_downloadfolder -Force
# Remove the Packer ZIP file
Remove-Item $global:packdownload

# Go to the Packer download folder
Set-Location $global:win11_downloadfolder

