Packer vSphere Windows 11
