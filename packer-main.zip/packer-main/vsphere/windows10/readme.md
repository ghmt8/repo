Packer vSphere Windows 10
