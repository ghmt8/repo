Packer Windows Server 2022

1. Download the Packer binary. More infor: https://www.ivobeerens.nl/2023/09/22/download-the-latest-hashicorp-terraform-packer-and-vault-bits/
2. Adjust the variables in the win2022-std.auto.pkvars.hcl
3. Adjust the locals in the win2022-std.config.pkr.hcl
4. Adjust the passwords in the autounattended.xml

